<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div>
        <?php include "php/header.php" ?>
        <h3 class="center">О нас</h3>
        <p class="center">Лишь представители современных социальных резервов, которые представляют собой яркий пример континентально-европейского типа политической культуры, будут в равной степени предоставлены сами себе. Повседневная практика показывает, что дальнейшее развитие различных форм деятельности способствует повышению качества системы массового участия. Лишь представители современных социальных резервов могут быть указаны как претенденты на роль ключевых факторов.</p>
    </div>
</body>

</html>